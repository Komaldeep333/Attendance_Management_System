-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2025 at 07:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendencemanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `AttendanceKey` int(5) NOT NULL,
  `EmployeeKey` int(5) NOT NULL,
  `Attendance_Date` date NOT NULL,
  `Attendance_Status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`AttendanceKey`, `EmployeeKey`, `Attendance_Date`, `Attendance_Status`) VALUES
(1, 1, '2024-07-15', 'Present'),
(2, 6, '2024-07-15', 'Present'),
(3, 4, '2024-07-15', 'Paid Leave'),
(4, 4, '2024-07-15', 'Medical Leave'),
(5, 9, '2024-07-12', 'Paid Leave'),
(6, 1, '2024-07-12', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DepartmentId` int(10) NOT NULL,
  `DepartmentName` varchar(50) NOT NULL,
  `DepartmentHead` varchar(30) NOT NULL,
  `DepartmentKey` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DepartmentId`, `DepartmentName`, `DepartmentHead`, `DepartmentKey`) VALUES
(100, 'Finance', 'Komaldeep', 1),
(101, 'Human Resources', 'Mohit', 2),
(103, 'sales', 'Muskan', 3),
(105, 'Production', 'param', 6);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EmployeeId` int(10) NOT NULL,
  `EmployeeName` varchar(50) NOT NULL,
  `FatherName` varchar(50) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `DepartmentKey` int(5) NOT NULL,
  `Designation` varchar(50) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `EmailId` varchar(50) NOT NULL,
  `StatusOfEmployee` varchar(10) NOT NULL,
  `EmployeeKey` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`EmployeeId`, `EmployeeName`, `FatherName`, `Gender`, `DepartmentKey`, `Designation`, `PhoneNumber`, `EmailId`, `StatusOfEmployee`, `EmployeeKey`) VALUES
(100, 'Komal', 'Mukhtar Singh', 'Female', 2, 'HR', '46546788', 'komal45@gmail.com', '1', 1),
(102, 'Kirandeep', 'Mukhtar Singh', 'Female', 2, 'Manager', '98543235', 'kiran@gmail.com', 'Female', 9),
(103, 'Kirandeep', 'Mukhtar S', 'Female', 2, 'assistant', '785534', 'kirandeep@gmail.com', 'Female', 11),
(104, 'muskan', 'dilip kumar', 'Female', 1, 'Assistant developer', '5465768', 'muskan@gmail.com', 'Female', 12),
(110, 'param', 'malkiat', 'Male', 6, 'DepHead', '565768', 'param@gmail.com', 'Male', 13),
(44, 'ggh', 'ghgh', 'Female', 0, 'HR', '78686', 'hghgh', 'Active', 14),
(45, 'sam', 'john', 'Male', 2, 'hjhj', '57676', 'hghf', 'Active', 15),
(121, 'samy', 'mny', 'Female', 6, 'HR', '56666666666', 'gfgfttdd', 'Active', 16);

-- --------------------------------------------------------

--
-- Table structure for table `leave_policy`
--

CREATE TABLE `leave_policy` (
  `LeavePolicyKey` int(10) NOT NULL,
  `AnnualMedicalLeaves` int(10) NOT NULL,
  `AnnualCasualLeaves` int(10) NOT NULL,
  `AnnualPaidLeaves` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leave_policy`
--

INSERT INTO `leave_policy` (`LeavePolicyKey`, `AnnualMedicalLeaves`, `AnnualCasualLeaves`, `AnnualPaidLeaves`) VALUES
(1, 12, 10, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`AttendanceKey`),
  ADD KEY `EmployeeKey` (`EmployeeKey`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`DepartmentKey`),
  ADD UNIQUE KEY `DepartmentId` (`DepartmentId`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EmployeeKey`),
  ADD UNIQUE KEY `EmployeeId` (`EmployeeId`),
  ADD KEY `DepartmentKey` (`DepartmentKey`);

--
-- Indexes for table `leave_policy`
--
ALTER TABLE `leave_policy`
  ADD PRIMARY KEY (`LeavePolicyKey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `AttendanceKey` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `DepartmentKey` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `EmployeeKey` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
